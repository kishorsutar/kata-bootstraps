package it.gabrieletondi.telldontaskkata.domain;

public enum OrderStatus {
    APPROVED, REJECTED, SHIPPED, CREATED
}
