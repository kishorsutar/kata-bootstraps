package it.gabrieletondi.telldontaskkata.useCase;

public class OrderCannotBeShippedTwiceException extends RuntimeException {
}
