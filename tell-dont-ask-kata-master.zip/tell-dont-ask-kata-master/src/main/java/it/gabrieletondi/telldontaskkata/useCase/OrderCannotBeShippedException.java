package it.gabrieletondi.telldontaskkata.useCase;

public class OrderCannotBeShippedException extends RuntimeException {
}
