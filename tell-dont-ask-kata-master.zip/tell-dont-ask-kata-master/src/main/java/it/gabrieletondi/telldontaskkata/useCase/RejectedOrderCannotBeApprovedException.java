package it.gabrieletondi.telldontaskkata.useCase;

public class RejectedOrderCannotBeApprovedException extends RuntimeException {
}
