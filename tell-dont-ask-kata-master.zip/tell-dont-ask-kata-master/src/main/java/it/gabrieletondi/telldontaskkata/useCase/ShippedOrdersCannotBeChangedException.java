package it.gabrieletondi.telldontaskkata.useCase;

public class ShippedOrdersCannotBeChangedException extends RuntimeException {
}
